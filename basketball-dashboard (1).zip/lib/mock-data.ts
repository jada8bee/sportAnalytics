export interface Player {
  id: string
  name: string
  team: string
  position: string
  jerseyNumber: number
  points: number
  rebounds: number
  assists: number
  steals: number
  blocks: number
  fieldGoalPercentage: number
  threePointPercentage: number
  freeThrowPercentage: number
  gamesPlayed: number
  imageUrl: string
}

export interface Team {
  id: string
  name: string
  city: string
  wins: number
  losses: number
  winPercentage: number
  pointsPerGame: number
  reboundsPerGame: number
  assistsPerGame: number
  logoUrl: string
}

export interface Game {
  id: string
  homeTeam: string
  awayTeam: string
  homeScore: number
  awayScore: number
  date: string
  status: "completed" | "upcoming" | "live"
  quarter?: string
}

export const mockPlayers: Player[] = [
  {
    id: "1",
    name: "LeBron James",
    team: "Los Angeles Lakers",
    position: "SF",
    jerseyNumber: 23,
    points: 27.2,
    rebounds: 7.5,
    assists: 7.3,
    steals: 1.3,
    blocks: 0.6,
    fieldGoalPercentage: 52.4,
    threePointPercentage: 38.5,
    freeThrowPercentage: 75.6,
    gamesPlayed: 56,
    imageUrl: "/basketball-player-in-action.png",
  },
  {
    id: "2",
    name: "Stephen Curry",
    team: "Golden State Warriors",
    position: "PG",
    jerseyNumber: 30,
    points: 29.4,
    rebounds: 5.1,
    assists: 6.3,
    steals: 1.2,
    blocks: 0.4,
    fieldGoalPercentage: 48.2,
    threePointPercentage: 42.7,
    freeThrowPercentage: 91.0,
    gamesPlayed: 64,
    imageUrl: "/diverse-basketball-players.png",
  },
  {
    id: "3",
    name: "Giannis Antetokounmpo",
    team: "Milwaukee Bucks",
    position: "PF",
    jerseyNumber: 34,
    points: 31.1,
    rebounds: 11.8,
    assists: 5.7,
    steals: 1.1,
    blocks: 1.4,
    fieldGoalPercentage: 55.3,
    threePointPercentage: 29.3,
    freeThrowPercentage: 72.2,
    gamesPlayed: 63,
    imageUrl: "/basketball-player-3.png",
  },
  {
    id: "4",
    name: "Kevin Durant",
    team: "Phoenix Suns",
    position: "SF",
    jerseyNumber: 35,
    points: 28.7,
    rebounds: 6.7,
    assists: 5.0,
    steals: 0.9,
    blocks: 1.3,
    fieldGoalPercentage: 53.7,
    threePointPercentage: 39.4,
    freeThrowPercentage: 91.9,
    gamesPlayed: 47,
    imageUrl: "/diverse-basketball-team.png",
  },
  {
    id: "5",
    name: "Luka Doncic",
    team: "Dallas Mavericks",
    position: "PG",
    jerseyNumber: 77,
    points: 32.4,
    rebounds: 8.6,
    assists: 8.0,
    steals: 1.4,
    blocks: 0.5,
    fieldGoalPercentage: 49.6,
    threePointPercentage: 37.3,
    freeThrowPercentage: 74.2,
    gamesPlayed: 66,
    imageUrl: "/basketball-player-five.png",
  },
  {
    id: "6",
    name: "Joel Embiid",
    team: "Philadelphia 76ers",
    position: "C",
    jerseyNumber: 21,
    points: 33.1,
    rebounds: 10.2,
    assists: 4.2,
    steals: 1.0,
    blocks: 1.7,
    fieldGoalPercentage: 54.8,
    threePointPercentage: 35.0,
    freeThrowPercentage: 85.7,
    gamesPlayed: 66,
    imageUrl: "/basketball-player-six.png",
  },
]

export const mockTeams: Team[] = [
  {
    id: "1",
    name: "Lakers",
    city: "Los Angeles",
    wins: 42,
    losses: 18,
    winPercentage: 70.0,
    pointsPerGame: 115.2,
    reboundsPerGame: 44.5,
    assistsPerGame: 26.3,
    logoUrl: "/lakers-logo.jpg",
  },
  {
    id: "2",
    name: "Warriors",
    city: "Golden State",
    wins: 38,
    losses: 22,
    winPercentage: 63.3,
    pointsPerGame: 118.4,
    reboundsPerGame: 42.1,
    assistsPerGame: 28.7,
    logoUrl: "/generic-warrior-logo.png",
  },
  {
    id: "3",
    name: "Bucks",
    city: "Milwaukee",
    wins: 45,
    losses: 15,
    winPercentage: 75.0,
    pointsPerGame: 119.8,
    reboundsPerGame: 46.2,
    assistsPerGame: 25.4,
    logoUrl: "/generic-deer-logo.png",
  },
  {
    id: "4",
    name: "Suns",
    city: "Phoenix",
    wins: 40,
    losses: 20,
    winPercentage: 66.7,
    pointsPerGame: 114.7,
    reboundsPerGame: 43.8,
    assistsPerGame: 27.1,
    logoUrl: "/stylized-phoenix-basketball.png",
  },
  {
    id: "5",
    name: "Mavericks",
    city: "Dallas",
    wins: 37,
    losses: 23,
    winPercentage: 61.7,
    pointsPerGame: 116.3,
    reboundsPerGame: 41.9,
    assistsPerGame: 24.8,
    logoUrl: "/mavericks-logo.png",
  },
  {
    id: "6",
    name: "76ers",
    city: "Philadelphia",
    wins: 43,
    losses: 17,
    winPercentage: 71.7,
    pointsPerGame: 117.5,
    reboundsPerGame: 45.3,
    assistsPerGame: 26.9,
    logoUrl: "/76ers-logo.png",
  },
]

export const mockGames: Game[] = [
  {
    id: "1",
    homeTeam: "Los Angeles Lakers",
    awayTeam: "Golden State Warriors",
    homeScore: 112,
    awayScore: 108,
    date: "2025-01-15",
    status: "completed",
  },
  {
    id: "2",
    homeTeam: "Milwaukee Bucks",
    awayTeam: "Phoenix Suns",
    homeScore: 125,
    awayScore: 118,
    date: "2025-01-15",
    status: "completed",
  },
  {
    id: "3",
    homeTeam: "Dallas Mavericks",
    awayTeam: "Philadelphia 76ers",
    homeScore: 98,
    awayScore: 102,
    date: "2025-01-16",
    status: "completed",
  },
  {
    id: "4",
    homeTeam: "Golden State Warriors",
    awayTeam: "Milwaukee Bucks",
    homeScore: 0,
    awayScore: 0,
    date: "2025-01-20",
    status: "upcoming",
  },
  {
    id: "5",
    homeTeam: "Phoenix Suns",
    awayTeam: "Los Angeles Lakers",
    homeScore: 0,
    awayScore: 0,
    date: "2025-01-21",
    status: "upcoming",
  },
  {
    id: "6",
    homeTeam: "Philadelphia 76ers",
    awayTeam: "Dallas Mavericks",
    homeScore: 0,
    awayScore: 0,
    date: "2025-01-22",
    status: "upcoming",
  },
]
