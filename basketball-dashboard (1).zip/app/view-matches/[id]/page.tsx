"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { mockGames } from "@/lib/mock-data"
import { ArrowLeft, Save, Pencil } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

interface PlayerMatchStats {
  playerId: string
  playerName: string
  team: string
  freeThrows: number
  freeThrowAttempts: number
  threePointers: number
  threePointAttempts: number
  twoPointers: number
  twoPointAttempts: number
  assists: number
  rebounds: number
  steals: number
  blocks: number
  fouls: number
}

export default function MatchDetailPage({ params }: { params: { id: string } }) {
  const game = mockGames.find((g) => g.id === params.id)
  const [editingPlayer, setEditingPlayer] = useState<string | null>(null)

  const [playerStats, setPlayerStats] = useState<PlayerMatchStats[]>([
    {
      playerId: "1",
      playerName: "LeBron James",
      team: "Los Angeles Lakers",
      freeThrows: 8,
      freeThrowAttempts: 10,
      threePointers: 3,
      threePointAttempts: 8,
      twoPointers: 7,
      twoPointAttempts: 12,
      assists: 7,
      rebounds: 8,
      steals: 2,
      blocks: 1,
      fouls: 2,
    },
    {
      playerId: "2",
      playerName: "Anthony Davis",
      team: "Los Angeles Lakers",
      freeThrows: 6,
      freeThrowAttempts: 8,
      threePointers: 1,
      threePointAttempts: 3,
      twoPointers: 9,
      twoPointAttempts: 15,
      assists: 3,
      rebounds: 12,
      steals: 1,
      blocks: 3,
      fouls: 3,
    },
    {
      playerId: "3",
      playerName: "Stephen Curry",
      team: "Golden State Warriors",
      freeThrows: 4,
      freeThrowAttempts: 4,
      threePointers: 8,
      threePointAttempts: 15,
      twoPointers: 4,
      twoPointAttempts: 8,
      assists: 6,
      rebounds: 5,
      steals: 1,
      blocks: 0,
      fouls: 1,
    },
    {
      playerId: "4",
      playerName: "Klay Thompson",
      team: "Golden State Warriors",
      freeThrows: 2,
      freeThrowAttempts: 2,
      threePointers: 5,
      threePointAttempts: 12,
      twoPointers: 3,
      twoPointAttempts: 6,
      assists: 2,
      rebounds: 4,
      steals: 2,
      blocks: 1,
      fouls: 2,
    },
  ])

  const updateStat = (playerId: string, field: keyof PlayerMatchStats, value: string) => {
    setPlayerStats((prev) =>
      prev.map((player) =>
        player.playerId === playerId
          ? { ...player, [field]: field === "playerName" || field === "team" ? value : Number.parseFloat(value) || 0 }
          : player,
      ),
    )
  }

  const handleSave = () => {
    setEditingPlayer(null)
    alert("Player statistics updated successfully!")
  }

  if (!game) {
    return (
      <DashboardLayout>
        <div className="text-center">
          <p className="text-muted-foreground">Match not found</p>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/view-matches">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">Match Details</h1>
            <p className="text-muted-foreground">View and edit player statistics for this match</p>
          </div>
        </div>

        <div className="space-y-1">
          <div className="text-sm text-muted-foreground">
            Match ID: <span className="font-semibold text-foreground">{game.id}</span>
          </div>
          <div className="text-sm text-muted-foreground">
            Date:{" "}
            <span className="font-semibold text-foreground">
              {new Date(game.date).toLocaleDateString("en-US", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </span>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Match Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="flex items-center justify-between rounded-lg border border-border bg-card p-4">
                <span className="font-semibold text-card-foreground">{game.homeTeam}</span>
                <span className="text-2xl font-bold text-primary">{game.homeScore}</span>
              </div>
              <div className="flex items-center justify-between rounded-lg border border-border bg-card p-4">
                <span className="font-semibold text-card-foreground">{game.awayTeam}</span>
                <span className="text-2xl font-bold text-card-foreground">{game.awayScore}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Player Statistics</CardTitle>
            <Button onClick={handleSave}>
              <Save className="mr-2 h-4 w-4" />
              Save Changes
            </Button>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="pb-3 text-left text-sm font-medium text-muted-foreground">Player</th>
                    <th className="pb-3 text-left text-sm font-medium text-muted-foreground">Team</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">FT/FTA</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">3PT/3PA</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">2PT/2PA</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">AST</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">REB</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">STL</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">BLK</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">FLS</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground w-12"></th>
                  </tr>
                </thead>
                <tbody>
                  {playerStats.map((player) => (
                    <tr
                      key={player.playerId}
                      className="group border-b border-border hover:bg-accent/50 transition-colors"
                      onMouseEnter={() => setEditingPlayer(player.playerId)}
                      onMouseLeave={() => setEditingPlayer(null)}
                    >
                      <td className="py-4 font-medium text-card-foreground">{player.playerName}</td>
                      <td className="py-4 text-sm text-muted-foreground">{player.team}</td>
                      <td className="py-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Input
                            type="number"
                            value={player.freeThrows}
                            onChange={(e) => updateStat(player.playerId, "freeThrows", e.target.value)}
                            className="w-14 text-center"
                          />
                          <span className="text-muted-foreground">/</span>
                          <Input
                            type="number"
                            value={player.freeThrowAttempts}
                            onChange={(e) => updateStat(player.playerId, "freeThrowAttempts", e.target.value)}
                            className="w-14 text-center"
                          />
                        </div>
                      </td>
                      <td className="py-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Input
                            type="number"
                            value={player.threePointers}
                            onChange={(e) => updateStat(player.playerId, "threePointers", e.target.value)}
                            className="w-14 text-center"
                          />
                          <span className="text-muted-foreground">/</span>
                          <Input
                            type="number"
                            value={player.threePointAttempts}
                            onChange={(e) => updateStat(player.playerId, "threePointAttempts", e.target.value)}
                            className="w-14 text-center"
                          />
                        </div>
                      </td>
                      <td className="py-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Input
                            type="number"
                            value={player.twoPointers}
                            onChange={(e) => updateStat(player.playerId, "twoPointers", e.target.value)}
                            className="w-14 text-center"
                          />
                          <span className="text-muted-foreground">/</span>
                          <Input
                            type="number"
                            value={player.twoPointAttempts}
                            onChange={(e) => updateStat(player.playerId, "twoPointAttempts", e.target.value)}
                            className="w-14 text-center"
                          />
                        </div>
                      </td>
                      <td className="py-4 text-center">
                        <Input
                          type="number"
                          value={player.assists}
                          onChange={(e) => updateStat(player.playerId, "assists", e.target.value)}
                          className="w-16 text-center mx-auto"
                        />
                      </td>
                      <td className="py-4 text-center">
                        <Input
                          type="number"
                          value={player.rebounds}
                          onChange={(e) => updateStat(player.playerId, "rebounds", e.target.value)}
                          className="w-16 text-center mx-auto"
                        />
                      </td>
                      <td className="py-4 text-center">
                        <Input
                          type="number"
                          value={player.steals}
                          onChange={(e) => updateStat(player.playerId, "steals", e.target.value)}
                          className="w-16 text-center mx-auto"
                        />
                      </td>
                      <td className="py-4 text-center">
                        <Input
                          type="number"
                          value={player.blocks}
                          onChange={(e) => updateStat(player.playerId, "blocks", e.target.value)}
                          className="w-16 text-center mx-auto"
                        />
                      </td>
                      <td className="py-4 text-center">
                        <Input
                          type="number"
                          value={player.fouls}
                          onChange={(e) => updateStat(player.playerId, "fouls", e.target.value)}
                          className="w-16 text-center mx-auto"
                        />
                      </td>
                      <td className="py-4 text-center">
                        <Button
                          variant="ghost"
                          size="icon"
                          className={`transition-opacity ${editingPlayer === player.playerId ? "opacity-100" : "opacity-0"}`}
                        >
                          <Pencil className="h-4 w-4 text-primary" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
