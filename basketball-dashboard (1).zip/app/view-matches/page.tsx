"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { mockGames } from "@/lib/mock-data"
import { Search } from "lucide-react"
import { useState } from "react"
import Link from "next/link"

export default function ViewMatchesPage() {
  const [searchQuery, setSearchQuery] = useState("")

  const completedGames = mockGames.filter((game) => game.status === "completed")

  const filteredGames = completedGames.filter(
    (game) =>
      game.homeTeam.toLowerCase().includes(searchQuery.toLowerCase()) ||
      game.awayTeam.toLowerCase().includes(searchQuery.toLowerCase()) ||
      game.id.includes(searchQuery),
  )

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">View Matches</h1>
          <p className="text-muted-foreground">Browse and manage all completed matches.</p>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Search className="h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="Search by team name or match ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1"
              />
            </div>
          </CardHeader>
        </Card>

        <div className="space-y-4">
          {filteredGames.map((game) => (
            <Link key={game.id} href={`/view-matches/${game.id}`}>
              <Card className="transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-4">
                        <span className="font-semibold text-card-foreground">{game.homeTeam}</span>
                        <span className="text-2xl font-bold text-primary">{game.homeScore}</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="font-semibold text-card-foreground">{game.awayTeam}</span>
                        <span className="text-2xl font-bold text-card-foreground">{game.awayScore}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-muted-foreground">Match ID: {game.id}</div>
                      <div className="mt-1 text-sm text-muted-foreground">
                        {new Date(game.date).toLocaleDateString()}
                      </div>
                      <div className="mt-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                        Final
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {filteredGames.length === 0 && (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">No matches found matching your search.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  )
}
