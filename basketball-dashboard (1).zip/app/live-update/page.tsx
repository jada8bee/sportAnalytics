"use client"

import type React from "react"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Activity } from "lucide-react"
import { useState } from "react"
import { useRouter } from "next/navigation"

export default function LiveUpdatePage() {
  const [matchId, setMatchId] = useState("")
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (matchId.trim()) {
      router.push(`/live-update/${matchId}`)
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Live Update</h1>
          <p className="text-muted-foreground">Enter a match ID to start live score updates.</p>
        </div>

        <Card className="mx-auto max-w-md">
          <CardHeader>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Activity className="h-5 w-5 text-primary" />
                <div className="absolute -right-1 -top-1 h-2 w-2 animate-pulse rounded-full bg-red-500" />
              </div>
              <CardTitle>Start Live Match</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="match-id">Match ID</Label>
                <Input
                  id="match-id"
                  placeholder="Enter match ID (e.g., 1, 2, 3...)"
                  value={matchId}
                  onChange={(e) => setMatchId(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                Start Live Update
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Available Matches</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <p className="text-muted-foreground">Quick access to recent matches:</p>
              <div className="grid gap-2 sm:grid-cols-2">
                <Button
                  variant="outline"
                  className="justify-start bg-transparent"
                  onClick={() => router.push("/live-update/1")}
                >
                  Match 1: Lakers vs Warriors
                </Button>
                <Button
                  variant="outline"
                  className="justify-start bg-transparent"
                  onClick={() => router.push("/live-update/2")}
                >
                  Match 2: Bucks vs Suns
                </Button>
                <Button
                  variant="outline"
                  className="justify-start bg-transparent"
                  onClick={() => router.push("/live-update/3")}
                >
                  Match 3: Mavericks vs 76ers
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
