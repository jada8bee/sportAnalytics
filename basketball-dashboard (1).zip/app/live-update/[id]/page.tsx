"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { mockGames } from "@/lib/mock-data"
import { ArrowLeft, Save, Pencil, Radio } from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"

interface PlayerMatchStats {
  playerId: string
  playerName: string
  team: string
  freeThrows: number
  freeThrowAttempts: number
  threePointers: number
  threePointAttempts: number
  twoPointers: number
  twoPointAttempts: number
  assists: number
  rebounds: number
  steals: number
  blocks: number
  fouls: number
}

export default function LiveUpdateMatchPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const game = mockGames.find((g) => g.id === params.id)

  const [homeScore, setHomeScore] = useState(game?.homeScore || 0)
  const [awayScore, setAwayScore] = useState(game?.awayScore || 0)
  const [quarter, setQuarter] = useState("Q1")
  const [editingPlayer, setEditingPlayer] = useState<string | null>(null)

  const [playerStats, setPlayerStats] = useState<PlayerMatchStats[]>([
    {
      playerId: "1",
      playerName: "LeBron James",
      team: "Los Angeles Lakers",
      freeThrows: 0,
      freeThrowAttempts: 0,
      threePointers: 0,
      threePointAttempts: 0,
      twoPointers: 0,
      twoPointAttempts: 0,
      assists: 0,
      rebounds: 0,
      steals: 0,
      blocks: 0,
      fouls: 0,
    },
    {
      playerId: "2",
      playerName: "Anthony Davis",
      team: "Los Angeles Lakers",
      freeThrows: 0,
      freeThrowAttempts: 0,
      threePointers: 0,
      threePointAttempts: 0,
      twoPointers: 0,
      twoPointAttempts: 0,
      assists: 0,
      rebounds: 0,
      steals: 0,
      blocks: 0,
      fouls: 0,
    },
    {
      playerId: "3",
      playerName: "Stephen Curry",
      team: "Golden State Warriors",
      freeThrows: 0,
      freeThrowAttempts: 0,
      threePointers: 0,
      threePointAttempts: 0,
      twoPointers: 0,
      twoPointAttempts: 0,
      assists: 0,
      rebounds: 0,
      steals: 0,
      blocks: 0,
      fouls: 0,
    },
    {
      playerId: "4",
      playerName: "Klay Thompson",
      team: "Golden State Warriors",
      freeThrows: 0,
      freeThrowAttempts: 0,
      threePointers: 0,
      threePointAttempts: 0,
      twoPointers: 0,
      twoPointAttempts: 0,
      assists: 0,
      rebounds: 0,
      steals: 0,
      blocks: 0,
      fouls: 0,
    },
  ])

  const updateStat = (playerId: string, field: keyof PlayerMatchStats, value: string) => {
    setPlayerStats((prev) =>
      prev.map((player) =>
        player.playerId === playerId
          ? { ...player, [field]: field === "playerName" || field === "team" ? value : Number.parseFloat(value) || 0 }
          : player,
      ),
    )
  }

  const handleSave = () => {
    alert("Live stats updated successfully!")
  }

  const handleMatchEnd = () => {
    if (confirm("Are you sure you want to end this live match?")) {
      router.push("/live-update")
    }
  }

  if (!game) {
    return (
      <DashboardLayout>
        <div className="text-center">
          <p className="text-muted-foreground">Match not found</p>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/live-update">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h1 className="text-3xl font-bold tracking-tight text-foreground">Live Match Update</h1>
              <div className="flex items-center gap-2 rounded-full bg-red-500/10 px-3 py-1">
                <div className="h-2 w-2 animate-pulse rounded-full bg-red-500" />
                <span className="text-sm font-medium text-red-500">LIVE</span>
              </div>
            </div>
            <p className="text-muted-foreground">Update scores and statistics in real-time</p>
          </div>
          <Button variant="destructive" onClick={handleMatchEnd}>
            Match End
          </Button>
        </div>

        <div className="space-y-1">
          <div className="text-sm text-muted-foreground">
            Match ID: <span className="font-semibold text-foreground">{game.id}</span>
          </div>
          <div className="text-sm text-muted-foreground">
            Date:{" "}
            <span className="font-semibold text-foreground">
              {new Date(game.date).toLocaleDateString("en-US", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </span>
          </div>
        </div>

        <Card className="border-red-500/50 bg-gradient-to-r from-red-500/5 to-red-500/10">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Live Score</CardTitle>
              <div className="flex items-center gap-2">
                <Radio className="h-4 w-4 text-red-500" />
                <span className="text-sm font-medium text-red-500">{quarter}</span>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">{game.homeTeam}</label>
                <Input
                  type="number"
                  value={homeScore}
                  onChange={(e) => setHomeScore(Number.parseInt(e.target.value) || 0)}
                  className="text-3xl font-bold text-primary"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">{game.awayTeam}</label>
                <Input
                  type="number"
                  value={awayScore}
                  onChange={(e) => setAwayScore(Number.parseInt(e.target.value) || 0)}
                  className="text-3xl font-bold"
                />
              </div>
            </div>
            <div className="mt-4 flex gap-2">
              {["Q1", "Q2", "Q3", "Q4", "OT"].map((q) => (
                <Button key={q} variant={quarter === q ? "default" : "outline"} size="sm" onClick={() => setQuarter(q)}>
                  {q}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Player Statistics</CardTitle>
            <Button onClick={handleSave}>
              <Save className="mr-2 h-4 w-4" />
              Save Live Stats
            </Button>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="pb-3 text-left text-sm font-medium text-muted-foreground">Player</th>
                    <th className="pb-3 text-left text-sm font-medium text-muted-foreground">Team</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">FT/FTA</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">3PT/3PA</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">2PT/2PA</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">AST</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">REB</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">STL</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">BLK</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">FLS</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground w-12"></th>
                  </tr>
                </thead>
                <tbody>
                  {playerStats.map((player) => (
                    <tr
                      key={player.playerId}
                      className="group border-b border-border hover:bg-accent/50 transition-colors"
                      onMouseEnter={() => setEditingPlayer(player.playerId)}
                      onMouseLeave={() => setEditingPlayer(null)}
                    >
                      <td className="py-4 font-medium text-card-foreground">{player.playerName}</td>
                      <td className="py-4 text-sm text-muted-foreground">{player.team}</td>
                      <td className="py-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Input
                            type="number"
                            value={player.freeThrows}
                            onChange={(e) => updateStat(player.playerId, "freeThrows", e.target.value)}
                            className="w-14 text-center"
                          />
                          <span className="text-muted-foreground">/</span>
                          <Input
                            type="number"
                            value={player.freeThrowAttempts}
                            onChange={(e) => updateStat(player.playerId, "freeThrowAttempts", e.target.value)}
                            className="w-14 text-center"
                          />
                        </div>
                      </td>
                      <td className="py-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Input
                            type="number"
                            value={player.threePointers}
                            onChange={(e) => updateStat(player.playerId, "threePointers", e.target.value)}
                            className="w-14 text-center"
                          />
                          <span className="text-muted-foreground">/</span>
                          <Input
                            type="number"
                            value={player.threePointAttempts}
                            onChange={(e) => updateStat(player.playerId, "threePointAttempts", e.target.value)}
                            className="w-14 text-center"
                          />
                        </div>
                      </td>
                      <td className="py-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Input
                            type="number"
                            value={player.twoPointers}
                            onChange={(e) => updateStat(player.playerId, "twoPointers", e.target.value)}
                            className="w-14 text-center"
                          />
                          <span className="text-muted-foreground">/</span>
                          <Input
                            type="number"
                            value={player.twoPointAttempts}
                            onChange={(e) => updateStat(player.playerId, "twoPointAttempts", e.target.value)}
                            className="w-14 text-center"
                          />
                        </div>
                      </td>
                      <td className="py-4 text-center">
                        <Input
                          type="number"
                          value={player.assists}
                          onChange={(e) => updateStat(player.playerId, "assists", e.target.value)}
                          className="w-16 text-center mx-auto"
                        />
                      </td>
                      <td className="py-4 text-center">
                        <Input
                          type="number"
                          value={player.rebounds}
                          onChange={(e) => updateStat(player.playerId, "rebounds", e.target.value)}
                          className="w-16 text-center mx-auto"
                        />
                      </td>
                      <td className="py-4 text-center">
                        <Input
                          type="number"
                          value={player.steals}
                          onChange={(e) => updateStat(player.playerId, "steals", e.target.value)}
                          className="w-16 text-center mx-auto"
                        />
                      </td>
                      <td className="py-4 text-center">
                        <Input
                          type="number"
                          value={player.blocks}
                          onChange={(e) => updateStat(player.playerId, "blocks", e.target.value)}
                          className="w-16 text-center mx-auto"
                        />
                      </td>
                      <td className="py-4 text-center">
                        <Input
                          type="number"
                          value={player.fouls}
                          onChange={(e) => updateStat(player.playerId, "fouls", e.target.value)}
                          className="w-16 text-center mx-auto"
                        />
                      </td>
                      <td className="py-4 text-center">
                        <Button
                          variant="ghost"
                          size="icon"
                          className={`transition-opacity ${editingPlayer === player.playerId ? "opacity-100" : "opacity-0"}`}
                        >
                          <Pencil className="h-4 w-4 text-primary" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
