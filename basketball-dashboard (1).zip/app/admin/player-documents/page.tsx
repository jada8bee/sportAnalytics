"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { FileText, Check, X, Clock } from "lucide-react"
import { useState } from "react"

interface PlayerDocument {
  id: string
  playerName: string
  documentType: string
  uploadDate: string
  status: "pending" | "approved" | "rejected"
  documentUrl: string
}

export default function PlayerDocumentsPage() {
  const [documents, setDocuments] = useState<PlayerDocument[]>([
    {
      id: "1",
      playerName: "LeBron James",
      documentType: "Medical Certificate",
      uploadDate: "2025-01-15",
      status: "pending",
      documentUrl: "/medical-certificate.png",
    },
    {
      id: "2",
      playerName: "Stephen Curry",
      documentType: "Contract Agreement",
      uploadDate: "2025-01-14",
      status: "pending",
      documentUrl: "/contract-agreement-document.jpg",
    },
    {
      id: "3",
      playerName: "Giannis Antetokounmpo",
      documentType: "Insurance Form",
      uploadDate: "2025-01-13",
      status: "approved",
      documentUrl: "/insurance-form.png",
    },
    {
      id: "4",
      playerName: "Kevin Durant",
      documentType: "ID Verification",
      uploadDate: "2025-01-12",
      status: "pending",
      documentUrl: "/id-verification-document.jpg",
    },
    {
      id: "5",
      playerName: "Luka Doncic",
      documentType: "Background Check",
      uploadDate: "2025-01-11",
      status: "rejected",
      documentUrl: "/background-check-document.jpg",
    },
  ])

  const updateStatus = (id: string, status: "approved" | "rejected") => {
    setDocuments((prev) => prev.map((doc) => (doc.id === id ? { ...doc, status } : doc)))
  }

  const viewDocument = (documentUrl: string) => {
    window.open(documentUrl, "_blank")
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="border-yellow-500 text-yellow-500">
            <Clock className="mr-1 h-3 w-3" />
            Pending
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="outline" className="border-green-500 text-green-500">
            <Check className="mr-1 h-3 w-3" />
            Approved
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="outline" className="border-red-500 text-red-500">
            <X className="mr-1 h-3 w-3" />
            Rejected
          </Badge>
        )
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Player Documents</h1>
          <p className="text-muted-foreground">Review and approve player document submissions.</p>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Pending Review</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-card-foreground">
                {documents.filter((d) => d.status === "pending").length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Approved</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-500">
                {documents.filter((d) => d.status === "approved").length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Rejected</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-500">
                {documents.filter((d) => d.status === "rejected").length}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          {documents.map((doc) => (
            <Card key={doc.id}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => viewDocument(doc.documentUrl)}
                      className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 hover:bg-primary/20 transition-colors cursor-pointer"
                      title="Click to view document"
                    >
                      <FileText className="h-6 w-6 text-primary" />
                    </button>
                    <div>
                      <h3 className="font-semibold text-card-foreground">{doc.playerName}</h3>
                      <p className="text-sm text-muted-foreground">{doc.documentType}</p>
                      <p className="text-xs text-muted-foreground">
                        Uploaded: {new Date(doc.uploadDate).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {getStatusBadge(doc.status)}
                    {doc.status === "pending" && (
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-green-500 text-green-500 hover:bg-green-500 hover:text-white bg-transparent"
                          onClick={() => updateStatus(doc.id, "approved")}
                        >
                          <Check className="mr-1 h-4 w-4" />
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white bg-transparent"
                          onClick={() => updateStatus(doc.id, "rejected")}
                        >
                          <X className="mr-1 h-4 w-4" />
                          Reject
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  )
}
