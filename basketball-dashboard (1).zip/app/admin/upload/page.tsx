"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Upload, FileSpreadsheet, Users, Trophy } from "lucide-react"
import { useState } from "react"

export default function UploadDataPage() {
  const [uploadStatus, setUploadStatus] = useState<string>("")

  const handleFileUpload = (type: string) => {
    setUploadStatus(`${type} data uploaded successfully!`)
    setTimeout(() => setUploadStatus(""), 3000)
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Upload Data</h1>
          <p className="text-muted-foreground">Upload player statistics, team data, and game results.</p>
        </div>

        {uploadStatus && (
          <Card className="border-primary bg-primary/5">
            <CardContent className="pt-6">
              <p className="text-center font-medium text-primary">{uploadStatus}</p>
            </CardContent>
          </Card>
        )}

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                <CardTitle>Player Data</CardTitle>
              </div>
              <CardDescription>Upload player statistics and information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="player-file">Select CSV or Excel file</Label>
                <Input id="player-file" type="file" accept=".csv,.xlsx,.xls" />
              </div>
              <Button onClick={() => handleFileUpload("Player")} className="w-full">
                <Upload className="mr-2 h-4 w-4" />
                Upload Player Data
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-primary" />
                <CardTitle>Team Data</CardTitle>
              </div>
              <CardDescription>Upload team statistics and standings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="team-file">Select CSV or Excel file</Label>
                <Input id="team-file" type="file" accept=".csv,.xlsx,.xls" />
              </div>
              <Button onClick={() => handleFileUpload("Team")} className="w-full">
                <Upload className="mr-2 h-4 w-4" />
                Upload Team Data
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="h-5 w-5 text-primary" />
                <CardTitle>Game Results</CardTitle>
              </div>
              <CardDescription>Upload game scores and match data</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="game-file">Select CSV or Excel file</Label>
                <Input id="game-file" type="file" accept=".csv,.xlsx,.xls" />
              </div>
              <Button onClick={() => handleFileUpload("Game")} className="w-full">
                <Upload className="mr-2 h-4 w-4" />
                Upload Game Data
              </Button>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Upload Guidelines</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary">•</span>
                <span>Accepted file formats: CSV, Excel (.xlsx, .xls)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">•</span>
                <span>Maximum file size: 10MB</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">•</span>
                <span>Ensure column headers match the required format</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">•</span>
                <span>Data will be validated before import</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
