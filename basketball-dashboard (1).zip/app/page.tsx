import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown, Users, Trophy, Activity, Upload, FileCheck, Eye } from "lucide-react"
import { mockPlayers, mockTeams, mockGames } from "@/lib/mock-data"
import Link from "next/link"

export default function DashboardPage() {
  const recentGames = mockGames.filter((game) => game.status === "completed").slice(0, 3)
  const topPerformers = mockPlayers.slice(0, 3)
  const topTeams = [...mockTeams].sort((a, b) => b.winPercentage - a.winPercentage).slice(0, 4)

  const stats = [
    {
      title: "Total Players",
      value: mockPlayers.length.toString(),
      change: "+12%",
      trend: "up" as const,
      icon: Users,
    },
    {
      title: "Active Teams",
      value: mockTeams.length.toString(),
      change: "0%",
      trend: "neutral" as const,
      icon: Trophy,
    },
    {
      title: "Games Played",
      value: mockGames.filter((g) => g.status === "completed").length.toString(),
      change: "+8%",
      trend: "up" as const,
      icon: Activity,
    },
    {
      title: "Avg Points/Game",
      value: "116.8",
      change: "+3.2%",
      trend: "up" as const,
      icon: TrendingUp,
    },
  ]

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back! Here's your basketball analytics overview.</p>
        </div>

        <Card className="border-primary/50 bg-gradient-to-r from-primary/5 to-primary/10">
          <CardHeader>
            <CardTitle className="text-card-foreground">Admin Access</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <Link
                href="/admin/upload"
                className="flex items-center gap-3 rounded-lg border border-border bg-card p-4 transition-all hover:border-primary hover:bg-accent"
              >
                <Upload className="h-5 w-5 text-primary" />
                <span className="font-medium text-card-foreground">Upload Data</span>
              </Link>
              <Link
                href="/view-matches"
                className="flex items-center gap-3 rounded-lg border border-border bg-card p-4 transition-all hover:border-primary hover:bg-accent"
              >
                <Eye className="h-5 w-5 text-primary" />
                <span className="font-medium text-card-foreground">View Matches</span>
              </Link>
              <Link
                href="/admin/player-documents"
                className="flex items-center gap-3 rounded-lg border border-border bg-card p-4 transition-all hover:border-primary hover:bg-accent"
              >
                <FileCheck className="h-5 w-5 text-primary" />
                <span className="font-medium text-card-foreground">Player Documents</span>
              </Link>
              <Link
                href="/live-update"
                className="flex items-center gap-3 rounded-lg border border-border bg-card p-4 transition-all hover:border-primary hover:bg-accent"
              >
                <div className="relative">
                  <Activity className="h-5 w-5 text-primary" />
                  <div className="absolute -right-1 -top-1 h-2 w-2 animate-pulse rounded-full bg-red-500" />
                </div>
                <span className="font-medium text-card-foreground">Live Update</span>
              </Link>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.title} className="transition-all hover:shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-card-foreground">{stat.title}</CardTitle>
                <stat.icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-card-foreground">{stat.value}</div>
                <div className="flex items-center gap-1 text-xs">
                  {stat.trend === "up" && <TrendingUp className="h-3 w-3 text-primary" />}
                  {stat.trend === "down" && <TrendingDown className="h-3 w-3 text-destructive" />}
                  <span className={stat.trend === "up" ? "text-primary" : "text-muted-foreground"}>
                    {stat.change} from last month
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-card-foreground">Recent Games</CardTitle>
              <Link
                href="/view-matches"
                className="text-sm font-medium text-primary transition-colors hover:text-primary/80"
              >
                View All Matches →
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentGames.map((game) => (
                  <div
                    key={game.id}
                    className="flex items-center justify-between rounded-lg border border-border bg-card p-4 transition-colors hover:bg-accent"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-card-foreground">{game.homeTeam}</span>
                        <span className="text-xl font-bold text-primary">{game.homeScore}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-card-foreground">{game.awayTeam}</span>
                        <span className="text-xl font-bold text-card-foreground">{game.awayScore}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-muted-foreground">{new Date(game.date).toLocaleDateString()}</div>
                      <div className="mt-1 rounded-full bg-primary/10 px-2 py-1 text-xs font-medium text-primary">
                        Final
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-card-foreground">Top Performers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topPerformers.map((player, index) => (
                  <div
                    key={player.id}
                    className="flex items-center gap-4 rounded-lg border border-border bg-card p-4 transition-colors hover:bg-accent"
                  >
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-lg font-bold text-primary-foreground">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-card-foreground">{player.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {player.team} • {player.position}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold text-primary">{player.points}</div>
                      <div className="text-xs text-muted-foreground">PPG</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-card-foreground">Team Standings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="pb-3 text-left text-sm font-medium text-muted-foreground">Rank</th>
                    <th className="pb-3 text-left text-sm font-medium text-muted-foreground">Team</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">W</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">L</th>
                    <th className="pb-3 text-center text-sm font-medium text-muted-foreground">Win %</th>
                    <th className="pb-3 text-right text-sm font-medium text-muted-foreground">PPG</th>
                  </tr>
                </thead>
                <tbody>
                  {topTeams.map((team, index) => (
                    <tr key={team.id} className="border-b border-border transition-colors hover:bg-accent">
                      <td className="py-4 text-card-foreground">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
                          {index + 1}
                        </div>
                      </td>
                      <td className="py-4">
                        <div className="font-semibold text-card-foreground">
                          {team.city} {team.name}
                        </div>
                      </td>
                      <td className="py-4 text-center font-medium text-card-foreground">{team.wins}</td>
                      <td className="py-4 text-center font-medium text-card-foreground">{team.losses}</td>
                      <td className="py-4 text-center">
                        <span className="rounded-full bg-primary/10 px-2 py-1 text-sm font-semibold text-primary">
                          {team.winPercentage.toFixed(1)}%
                        </span>
                      </td>
                      <td className="py-4 text-right font-semibold text-card-foreground">
                        {team.pointsPerGame.toFixed(1)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
